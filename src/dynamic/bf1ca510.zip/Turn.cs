﻿namespace rocket_bot;

public enum Turn
{
	None = 0,
	Left = -1,
	Right = 1
}